package version

var VERSION = "2020-07-08-01"

func GetVersion() (version string) {
	return VERSION
}
