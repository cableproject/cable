package models

type Cnf struct {
	CnfUnits []CnfUnit `json:"cnfUnits" bson:"cnfUnits"`
}
